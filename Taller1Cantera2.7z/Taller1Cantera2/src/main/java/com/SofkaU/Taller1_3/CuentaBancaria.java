
package com.SofkaU.Taller1_3;

/**
 *
 * @author juans
 */
public class CuentaBancaria {

    /**
     * Se establecen los tipos de atributos.(publicos, privados)
     */
    private int accountNumber;
    protected boolean actived;

    /**
     * Se crean los metodos get y set, con los cuales encapsulo la variable name
     * y la retorno por el metodo get una vez capturada.
     *
     * @return
     */
    public int getAccountNumber() {
        return this.accountNumber;
    }

    public void setAccountNumber(int accountNumber) {
        this.accountNumber = accountNumber;
    }

    public boolean isActived() {
        return this.actived;
    }

    public void setActived(boolean actived) {
        this.actived = actived;
    }

}
