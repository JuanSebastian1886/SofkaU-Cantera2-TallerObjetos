package com.SofkaU.Taller1_3;
import java.util.Scanner;

/**
 *
 * @author juans
 */
public class Main {

    public static void main(String[] args) {

        /**
         * Se establece un objeto de la clase CuentaBancaria
         */
        CuentaBancaria cuenta1 = new CuentaBancaria();
        Scanner entry = new Scanner(System.in);
        
        /**
         * Se quiere probar el instanciamiento de los atributos de clase Se
         * solicita por consola los atributos accountNumber y actived
         */
        
        System.out.println("Ingrese el numero de la cuenta:");
        int account = entry.nextInt();
        cuenta1.setAccountNumber(account);
        System.out.println("");
        
        System.out.println("Esta activa la cuenta?");
        boolean condition = entry.nextBoolean();
        cuenta1.setActived(condition);
        System.out.println("");
        
        System.out.println("Su cuenta con numero: "+ cuenta1.getAccountNumber()+ 
                " tiene un estado (activa= true o inactiva=false) : "
                + cuenta1.actived);
    }
}
