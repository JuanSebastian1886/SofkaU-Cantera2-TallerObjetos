package com.SofkaU.Taller1_2;
import java.util.ArrayList;

/**
 *
 * @author juans
 * Se crea la clase Fruta
 */
public class Fruta {
    /**
     * Se establecen los tipos de atributos.(publicos, privados)
     */
    public String name;
    private float averageWeight;
    public ArrayList<String> colors;
    /**
     * Se crean los metodos get y set, con los cuales encapsulo la variable name
     * y la retorno por el metodo get una vez capturada.
     * @return 
     */

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public float getAverageWeight() {
        return this.averageWeight;
    }

    public void setAverageWeight(float averageWeight) {
        this.averageWeight = averageWeight;
    }

    public ArrayList<String> getColors() {
        return colors;
    }

    public void setColors(ArrayList<String> colors) {
        this.colors = colors;
    }          
}
