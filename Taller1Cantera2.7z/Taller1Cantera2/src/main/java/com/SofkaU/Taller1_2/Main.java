/**
 * Hago el importe de la libreria del Scanner
 */
package com.SofkaU.Taller1_2;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author juans
 */
public class Main {

    public static void main(String[] args) {
        /**
         * Se establece un objeto de la clase Fruta
         */
        Fruta fruta1 = new Fruta();
        ArrayList<String> colors = new ArrayList<String>();
        Scanner entry = new Scanner(System.in);

        /**
         * Se quiere probar el instanciamiento de los atributos de clase Se
         * solicita por consola los atributos de name, averageWeight,color
         */
        System.out.println("Ingrese el nombre de la fruta:");
        String name = entry.nextLine();
        fruta1.setName(name);
        System.out.println("");
        
        System.out.println("Ingrese el color de la fruta:");
        String color = entry.next();
        colors.add(color);
        System.out.println("");
        
        //colors.add("amarilla");
        System.out.println("Ingrese el peso promedio la fruta:");
        float averageWeight = entry.nextFloat();
        fruta1.setAverageWeight(averageWeight);
        System.out.println("");
        /**
         * Como el atributo averageWeight es privado lo imprimo por medio del
         * get
         */
        System.out.println("La fruta: " + fruta1.name
                + " su color es: " + colors.get(0) + " y su peso es: " + fruta1.getAverageWeight());

    }
}
