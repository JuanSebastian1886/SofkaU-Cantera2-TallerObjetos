package com.SofkaU.Taller1_5;

import java.util.Scanner;

/**
 *
 * @author juans
 */
public class Main {

    public static void main(String[] args) {
        /**
         * Se quiere probar el instanciamiento de los atributos de clase Se
         * solicita por consola los atributos
         */
        Fidecomiso fide= new Fidecomiso();
        Scanner entry = new Scanner(System.in);

        System.out.println("Ingrese el propietario de la cuenta:");
        String name = entry.nextLine();
        fide.setOwner(name);
        System.out.println("");
        
        System.out.println("En que país se encuentra radicada?");
        String location = entry.nextLine();
        fide.setCountry(location);
        System.out.println("");

        System.out.println("Que tipo de cuenta es?");
        String type = entry.nextLine();
        fide.setAccount(type);
        System.out.println("");

        System.out.println("Cúal es el numero de cuenta?");
        int numberA = entry.nextInt();
        fide.setAccountNumber(numberA);
        System.out.println("");
      
        System.out.println("Quien es su benecifiario?");
        String partner = entry.nextLine();
        fide.setBeneficiary(partner);
        System.out.println("");

        System.out.println( fide.owner+" tiene un fidecomiso en el país: "
                + fide.getCountry() + " de tipo "+fide.getAccount()+" con numero "
                + "de cuenta " +fide.getAccountNumber()+ " y su benecifiario es:"
                + fide.beneficiary);                
    }
}
