package com.SofkaU.Taller1_5;

/**
 *
 * @author juans
 */
public class Fidecomiso {

    /**
     * Se establecen los tipos de atributos.(publicos, privados y protegidos)
     */
    private String account;
    private int accountNumber;
    private String country;
    protected String owner;
    protected String beneficiary;

    /**
     * Al ser atributos privados y protegidos se ahce muy revelante los metodos
     * set y get para la manipulacion de la informacion.
     * @return
     */
    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public int getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(int accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    public String getBeneficiary() {
        return beneficiary;
    }

    public void setBeneficiary(String beneficiary) {
        this.beneficiary = beneficiary;
    }

}
