
package com.SofkaU.Taller1_4;
import java.util.Scanner;

/**
 *
 * @author juans
 */
public class Main {
    public static void main(String[] args) {
        /**
         * Se establece un objeto de la clase 
         */
        Carro carro1 = new Carro();
        Scanner entry = new Scanner(System.in);
        /**
         * Se quiere probar el instanciamiento de los atributos de clase Se
         * solicita por consola los atributos accountNumber y actived
         */
        System.out.println("Ingrese la marca del carro:");
        String trademark  = entry.nextLine();
        carro1.setBrand(trademark);
        System.out.println("");
        
        System.out.println("Cúal es la placa del vehiculo?");
        String plate  = entry.nextLine();
        carro1.setPlate(plate);
        System.out.println("");
        
        System.out.println("Cúal es el numero del chasis?");
        int numberC  = entry.nextInt();
        carro1.setChassisNumber(numberC);
        System.out.println("");
        
        System.out.println("Cúal es el numero serial del motor?");
        int numberM  = entry.nextInt();
        carro1.setEngineSerial(numberM);
        System.out.println("");
        
        
        System.out.println("Cúal es el peso del vehiculo?");
        float weight  = entry.nextFloat();
        carro1.setWeight(weight);
        System.out.println("");
        
        System.out.println("El vehiculo "+ carro1.brand+ 
                " con placa "+ carro1.plate + " ingresa al taller y se deja "
                + " en la bitacora su numero de chasis: "+carro1.chassisNumber
                + " , serial del motor: " +carro1.getEngineSerial()+" y su peso:"
                +carro1.getWeight()+"T");              
    }    
}
