
package com.SofkaU.Taller1_4;

/**
 *
 * @author juans
 */
public class Carro {
    /**
     * Se establecen los tipos de atributos.(publicos, privados y protegidos)
     */
    public String plate;
    public String brand;
    protected int chassisNumber;
    private int engineSerial;
    private float weight;
/**
     * Se crean los metodos get y set, con los cuales encapsulo la variable name
     * y la retorno por el metodo get una vez capturada.
     *
     * @return
     */
   /**
     * Se crean los metodos get y set, con los cuales encapsulo los atributos
     * y los retorno por el metodo get una vez capturada.
     *
     * @return
     */
    
    public String getPlate() {
        return plate;
    }

    public void setPlate(String plate) {
        this.plate = plate;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public int getChassisNumber() {
        return chassisNumber;
    }

    public void setChassisNumber(int chassisNumber) {
        this.chassisNumber = chassisNumber;
    }

    public int getEngineSerial() {
        return engineSerial;
    }

    public void setEngineSerial(int engineSerial) {
        this.engineSerial = engineSerial;
    }

    public float getWeight() {
        return weight;
    }

    public void setWeight(float weight) {
        this.weight = weight;
    }
    
}
