
package com.SofkaU.Taller1;
import java.util.Date;

/**
 *
 * @author juans
 * Se crea la clase persona
 */
public class Persona {
    /**
     * Se establecen los atributos de la clase Persona.
     * Para este punto son todos publicos.
     */
    public String name;
    public String lastName1;
    public String lastName2;
    public Date dateBirth;
    public float height;

    /**
     * Se crean los metodos get y set, con los cuales encapsulo la variable name
     * y la retorno por el metodo get una vez capturada.
     * @return 
     */
    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }      

    public String getLastName1() {
        return lastName1;
    }

    public void setLastName1(String lastName1) {
        this.lastName1 = lastName1;
    }

    public String getLastName2() {
        return lastName2;
    }

    public void setLastName2(String lastName2) {
        this.lastName2 = lastName2;
    }

    public Date getDateBirth() {
        return dateBirth;
    }

    public void setDateBirth(Date dateBirth) {
        this.dateBirth = dateBirth;
    }

    public float getHeight() {
        return height;
    }

    public void setHeight(float height) {
        this.height = height;
    }
    
}


