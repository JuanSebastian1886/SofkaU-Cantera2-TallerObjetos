/**
 * Importo la libreria del scanner y relaciono el archivo al package
 */

package com.SofkaU.Taller1;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        /**
         * Se establece un objeto de la clase Persona
         */
        Persona persona1 = new Persona();        
        Scanner entry=new Scanner(System.in);
        /**
         * Se quiere probar el instanciamiento de los atributos de clase
         * Se solicita por consola los atributos de name, lastName,height
         */
        System.out.println("Ingrese su nombre:");
        String name=entry.nextLine();
        persona1.setName(name);
        System.out.println("Su nombre es: "+ persona1.name);
        
        System.out.println("Ingrese su primer apellido:");
        String lastName=entry.nextLine();
        persona1.setLastName1(lastName);
        System.out.println("Su primer apellido es: "+ persona1.lastName1);
        
        System.out.println("Ingrese su segundo apellido:");
        String lastName2=entry.nextLine();
        persona1.setLastName2(lastName2);
        System.out.println("Su segundo apellido es: "+ persona1.lastName2);
        
        System.out.println("Ingrese su segundo apellido:");
        float height=entry.nextFloat();
        persona1.setHeight(height);
        System.out.println("Su segundo apellido es: "+ persona1.height);
    }
}
