package com.SofkaU.Taller1_6;

import java.util.Scanner;

/**
 *
 * @author juans
 */
public class Main {

    public static void main(String[] args) {

        /**
         * Se establece un objeto de la clase Persona
         */
        CajaFuerte caja = new CajaFuerte();
        Scanner entry = new Scanner(System.in);
        /**
         * Se quiere probar el instanciamiento de los atributos de clase Se
         * solicita por consola los atributos accountNumber y actived
         */
        System.out.println("Ingrese la marca de la caja fuerte:");
        String safe = entry.nextLine();
        caja.setBrand(safe);
        System.out.println("");

        System.out.println("Cúal es la capacidad de la caja fuerte");
        float vol = entry.nextFloat();
        caja.setCapacity(vol);
        System.out.println("");

        System.out.println("Cúal es el el color de la caja fuerte");
        String color = entry.nextLine();
        caja.setColor(color);
        System.out.println("");

        System.out.println("Ingrese el password");
        int pass = entry.nextInt();
        caja.setPassword(pass);
        System.out.println("");

        System.out.println("Cuantos intentos se permiten?");
        int opportunities = entry.nextInt();
        caja.setTries(opportunities);
        System.out.println("");
        
        System.out.println("La caja fuerte es de color:  " + caja.color
                + " de marca " + caja.getBrand() + "con capacidad de almacenamiento de "
                + caja.capacity + " , tiene el codigo de apertura: " + caja.getPassword() 
                + " y permite " + caja.getTries()+" intentos antes de bloquearse");               
    }
}
